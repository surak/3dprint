                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2591857
M4 Screw Set for Pixar Lamp by tongngochuunghia is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

The M4 Screw Set support connection for the parts of the Pixar Lamp.
Link to Pixar Lamp: https://www.thingiverse.com/thing:2236339

Mini Wrench Kit - M3 , M4 , M5 , M6:
Link to M4 Wrench: https://www.thingiverse.com/thing:767525

# Print Settings

Printer: Anet A8 Prusa i3
Rafts: No
Supports: No
Resolution: 0.1
Infill: 100%

Notes: 
<ul>
<li>Speed: 50 - 60</li>
<li>Build Plate Adhesion Type: Brim</li>
<li>Brim Line Count: 4</li>
</ul>
<p>Please printing with infill 100%! Becomes stronger.</p>